﻿namespace ZbW.Testing.Dms.Client.Model
{
    internal class MetadataItem
    {
        // TODO: Write your Metadata properties here
    }
}